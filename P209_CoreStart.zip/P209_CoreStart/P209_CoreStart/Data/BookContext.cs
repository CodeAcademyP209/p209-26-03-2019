﻿using Microsoft.EntityFrameworkCore;
using P209_CoreStart.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P209_CoreStart.Data
{
    public class BookContext : DbContext
    {
        public BookContext(DbContextOptions<BookContext> options) : base(options)
        {
        }

        public DbSet<Category> Categories{ get; set; }
        public DbSet<Book> Books { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Category>().HasData(
                new Category() { Id = 1, Name = "Crime" },
                new Category() { Id = 2, Name = "Love" },
                new Category() { Id = 3, Name = "Dram" },
                new Category() { Id = 4, Name = "Adventure" }
            );

            modelBuilder.Entity<Book>().HasData(
                new Book() { Id = 1, Name = "Book 1", CategoryId = 1, Image = "books/book1.png" },
                new Book() { Id = 2, Name = "Book 2", CategoryId = 2, Image = "books/book1.png" },
                new Book() { Id = 3, Name = "Book 3", CategoryId = 3, Image = "books/book1.png" },
                new Book() { Id = 4, Name = "Book 4", CategoryId = 4, Image = "books/book1.png" }
            );
        }
    }
}
