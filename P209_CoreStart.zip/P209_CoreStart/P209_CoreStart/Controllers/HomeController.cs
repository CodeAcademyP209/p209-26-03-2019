﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using P209_CoreStart.Models;
using P209_CoreStart.Data;

namespace P209_CoreStart.Controllers
{
    public class HomeController : Controller
    {
        private readonly BookContext _context;
        private readonly RandomGenerator _randomGenerator;
        private readonly RandomGenerator _randomGenerator2;

        public HomeController(BookContext context, RandomGenerator randomGenerator, RandomGenerator randomGenerator2)
        {
            _context = context;
            _randomGenerator = randomGenerator;
            _randomGenerator2 = randomGenerator2;
        }

        public IActionResult Index()
        {
            return View(_context.Books);
        }

        public IActionResult About()
        {
            ViewBag.Number1 = _randomGenerator.Number;
            ViewBag.Number2 = _randomGenerator2.Number;

            return View();
        }

        public IActionResult Contact()
        {
            ViewBag.Number1 = _randomGenerator.Number;
            ViewBag.Number2 = _randomGenerator2.Number;

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
