﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using P209_CoreStart.Models;
using P209_CoreStart.Data;

namespace P209_CoreStart.Controllers
{
    public class BooksController : Controller
    {
        private readonly BookContext _context;

        public BooksController(BookContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Create()
        {
            ViewBag.Categories = _context.Categories;
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind(include: "Name, Photo, CategoryId")]Book book)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.Categories = _context.Categories;
                return View(book);
            }

            if(book.Photo == null)
            {
                ModelState.AddModelError("Photo", "Photo should be selected.");
                ViewBag.Categories = _context.Categories;
                return View(book);
            }

            _context.Books.Add(book);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }
    }
}